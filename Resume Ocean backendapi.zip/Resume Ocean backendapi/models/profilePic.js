const mongoose = require('mongoose');

const profilePicSchema = mongoose.Schema({
    image: {
        type: String,
        default: ''
    },
    images: [
        {
            type: String
        }
    ],
  
})

profilePicSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

profilePicSchema.set('toJSON', {
    virtuals: true,
});


exports.ProfilePic = mongoose.model('ProfilePic', profilePicSchema);
