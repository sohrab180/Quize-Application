const mongoose = require('mongoose');

const lectureSchema = mongoose.Schema({
    titleSubjectLecture: {
        type: String,
    },
    namePlaceInstitution: { 
        type: String,
    },
    dateLecture:{
        type: String, 
    },
    duration:{
        type: String,  
    }

})
lectureSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

lectureSchema.set('toJSON', {
    virtuals: true,
});

exports.Lecture = mongoose.model('Lecture', lectureSchema);
