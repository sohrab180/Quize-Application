const mongoose = require('mongoose');

const journalSchema = mongoose.Schema({
    
    publicationType: {
        type: String,
    },
    nameOfJournal: { 
        type: String,
    },
    titleOfArticle:{
        type: String, 
    },
    volume:{
        type: String, 
    },
    whetherSoleAuthor:{
        type: String, 
    },
    nameOfPublisher: {
        type: String,
    },
    monthYearOfpublication:{
        type:String
    },
    referred :{
        type:String 
    },
    indexing : {
        type:String   
    },
    isbn:{
        type:String     
    }

})
journalSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

journalSchema.set('toJSON', {
    virtuals: true,
});

exports.Journal = mongoose.model('Journal', journalSchema);
