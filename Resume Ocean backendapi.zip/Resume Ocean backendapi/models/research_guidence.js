const mongoose = require('mongoose');

const rGuidenceSchema = mongoose.Schema({
    nameScholar: {
        type: String,
    },
    nameDegree: { 
        type: String,
    },
    typeGuidence:{
        type: String, 
    },
    status:{
        type: String, 
    },
    instituteName: { 
        type: String,
    },
    typeWork:{
        type: String, 
    },
    yearAwarded:{
        type: String, 
    }

})
rGuidenceSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

rGuidenceSchema.set('toJSON', {
    virtuals: true,
});

exports.Rguidence = mongoose.model('Rguidence', rGuidenceSchema);
