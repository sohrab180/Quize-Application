const mongoose = require('mongoose');

const presentationSchema = mongoose.Schema({
    titleSubjectpresented: {
        type: String,
    },
    subjectSeminar: { 
        type: String,
    },
    organizingInstitutioName:{
        type: String, 
    },
    durationFrom: {
        type: String,
    },
    durationTo: { 
        type: String,
    },
    whetherProceedingsPublished:{
        type: String, 
    }

})
presentationSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

presentationSchema.set('toJSON', {
    virtuals: true,
});

exports.Presentaion = mongoose.model('Presentaion', presentationSchema);
