const mongoose = require('mongoose');

const patentSchema = mongoose.Schema({
    application: {
        type: String,
    },
    topic: { 
        type: String,
    },
    status:{
        type: String, 
    }

})
patentSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

patentSchema.set('toJSON', {
    virtuals: true,
});

exports.Patent = mongoose.model('Patent', patentSchema);
