const mongoose = require('mongoose');

const bookChapterSchema = mongoose.Schema({
    sNo: {
        type: String,
        
    },
    booktittle: {
        type: String,
    },
    publisher: { 
        type: String,
    },

    status: {
        type: String,
    }

})


bookChapterSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

bookChapterSchema.set('toJSON', {
    virtuals: true,
});

exports.Bookchapter = mongoose.model('Bookchapter', bookChapterSchema);
