const mongoose = require('mongoose');

const miscellenousSchema = mongoose.Schema({

    otherRelevant:{
        type: String,
    },
    name: {
        type: String,
    },
    designation: { 
        type: String,
    },
    organization:{
        type: String, 
    },
    mobile:{
        type: String,  
    },
    email:{
        type: String,    
    }

})
miscellenousSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

miscellenousSchema.set('toJSON', {
    virtuals: true,
});

exports.Miscellenous = mongoose.model('Miscellenous', miscellenousSchema);
