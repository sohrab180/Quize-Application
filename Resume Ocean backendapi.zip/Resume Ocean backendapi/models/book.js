const mongoose = require('mongoose');

const bookSchema = mongoose.Schema({
    sNo: {
        type: String,
        
    },
    application: {
        type: String,
    },
    topic: { 
        type: String,
    },

    status: {
        type: String,
    }

})


bookSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

bookSchema.set('toJSON', {
    virtuals: true,
});

exports.Book = mongoose.model('Book', bookSchema);
