const mongoose = require('mongoose');

const conferenceSchema = mongoose.Schema({
    nameCourseCertificationWorkshopConferences: {
        type: String,
        
    },
    eventType: {
        type: String,
    },
    attendOrganized: { 
        type: String,
    },

    sponsoringInstitution: {
        type: String,
    },
    periodFrom: { 
        type: String,
    },

    periodTo: {
        type: String,
    }

})


conferenceSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

conferenceSchema.set('toJSON', {
    virtuals: true,
});

exports.Conference = mongoose.model('Conference', conferenceSchema);
