const mongoose = require('mongoose');

const dataSchema = new mongoose.Schema({

    profile: {
        fullname: String,
        dob: String,
        age: String,
        fathersname: String,
        mothersname: String,
        metrial: String,
        spaousename: String,
        mobile: Number,
        email: String,
        addres: String,
        city: String,
        state: String,
        postcode: String,
        paddres: String,
        pcity: String,
        pstate: String,
        ppostcode: String,
        pnationality: String,
        linkedIn: String,
        facebook: String,
        twitter: String,
        instagram: String,
        ocidId: String,
        hIndex: String,
        citationIndex: String,
        summaryDetails: String
    },
    education: {
        sNo: String,
        degree: String,
        course: String,
        marks: String,
        boardsName: String,
        yearOfPass: String,
        phdAwarded: String,
        titleofPhD: String,
        specializationPhD: String,
    },
    book: {
        sNo: String,
        application: String,
        topic: String,
        status: String,
    },
    co_curricullar1: {
        activityName: String,
        nature: String,
        extentionThrough: String,
        monthYear: String,
        organization: String,
    },
    conference: {
        nameCourseCertificationWorkshopConferences: String,
        eventType: String,
        attendOrganized: String,
        sponsoringInstitution: String,
        periodFrom: String,
        periodTo: String,
    },
    employement: {
        nameOfEmployer: String,
        postDesignation: String,
        periodOfEmploymentFrom: String,
        periodOfEmploymentTo: String,
        grossSalary: String,
        responsibilities: String,
    },
    journal: {
        publicationType: String,
        nameOfJournal: String,
        titleOfArticle: String,
        volume: String,
        whetherSoleAuthor: String,
        nameOfPublisher: String,
        monthYearOfpublication: String,
        referred: String,
        indexing: String,
        isbn: String
    },
    lecture:{
        titleSubjectLecture:String,
        namePlaceInstitution:String,
        dateLecture:String, 
        duration:String,  
    
    },
    miscellenous:{
        otherRelevant:String,
        name:String,
        designation: String,
        organization:String, 
        mobile:String,  
        email:String,    
    },
    patents:{
        application:String,
        topic:String,
        status:String, 
    },
    presentation:{
        titleSubjectpresented: String,
        subjectSeminar: String,
        organizingInstitutioName:String, 
        durationFrom: String,
        durationTo: String,
        whetherProceedingsPublished:String, 
    },
    researchGuidence:{
        nameScholar:String,
        nameDegree:String,
        typeGuidence:String, 
        status:String, 
        instituteName: String,
        typeWork:String, 
        yearAwarded:String, 
    },
    researchProject:{
        associated: String,
        sponsoringAgency: String,
        title:String, 
        status:String, 
        noMastersAwarded:String,
        noPhDAwarded:String, 
        noPublications:String, 
        noPatent:String,
        budget:String,   
    }



});

dataSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

dataSchema.set('toJSON', {
    virtuals: true,
});

exports.DigitalResume = mongoose.model('DigitalResume', dataSchema);
exports.dataSchema = dataSchema;
