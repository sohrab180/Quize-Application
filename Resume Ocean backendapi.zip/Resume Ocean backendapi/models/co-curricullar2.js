const mongoose = require('mongoose');

const coCurricularSchema2 = mongoose.Schema({
    

    instName: {
        type: String,
        
    },
    degree: {
        type: String,
        
    },
    responsibilities:{
        type: String,
    },
    periodFrom:{
        type: String, 
    },
    periodTo:{
        type: String,  
    }
   

})


coCurricularSchema2.virtual('id').get(function () {
    return this._id.toHexString();
});

coCurricularSchema2.set('toJSON', {
    virtuals: true,
});

exports.CoCurricullar2 = mongoose.model('CoCurricullar2', coCurricularSchema2);
