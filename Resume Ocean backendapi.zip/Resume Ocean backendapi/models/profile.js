const mongoose = require('mongoose');

const profileSchema = mongoose.Schema({
    user_id: {
        type: String,
        
    },
    fullname: {
        type: String,
        
    },
    dob: {
        type: String,
    },
    age: {
        type: String,
    },
    fathersname: { 
        type: String,
    },
    mothersname: {
        type: String,
       
    },
    metrial: {
        type: String,
    },
    spaousename: { 
        type: String,
    },
    mobile:{
        type:Number,
    },
    email:{
        type:String
    },
    addres: {
        type: String,
        
    },
    city: {
        type: String,
    },
    state: { 
        type: String,
    },

    postcode: {
        type: String,
    },
    paddres: {
        type: String,
        
    },
    pcity: {
        type: String,
    },
    pstate: { 
        type: String,
    },

    ppostcode: {
        type: String,
    },
    pnationality: {
        type: String,
    },
    linkedIn:{
        type:String
    },
    facebook:{
        type:String
    },
    twitter:{
        type:String
    },
    instagram:{
        type:String
    },
    ocidId:{
        type:String
    },
    hIndex:{
        type:String
    },
    citationIndex:{
        type:String
    },
    summaryDetails:{
        type:String 
    }

})


profileSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

profileSchema.set('toJSON', {
    virtuals: true,
});

exports.Profile = mongoose.model('Profile', profileSchema);
