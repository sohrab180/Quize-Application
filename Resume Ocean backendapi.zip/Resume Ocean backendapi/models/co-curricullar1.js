const mongoose = require('mongoose');

const coCurricularSchema1 = mongoose.Schema({
    

    activityName: {
        type: String,
        
    },
    nature: {
        type: String,
        
    },
    extentionThrough:{
        type: String,
    },
    monthYear:{
        type: String, 
    },
    organization:{
        type: String,  
    }
   

})


coCurricularSchema1.virtual('id').get(function () {
    return this._id.toHexString();
});

coCurricularSchema1.set('toJSON', {
    virtuals: true,
});

exports.CoCurricullar1 = mongoose.model('CoCurricullar1', coCurricularSchema1);
