const mongoose = require('mongoose');

const prosonalSchema = mongoose.Schema({
     presentEmp:{
        type:String
    },
    designation:{
        type:String
    },
    majorOfArea:{
        type:String
    },
  
   
    // image: {
        
    //     type: String,
    //     default: ''
    // },
    // images: [
    //     {
           
    //         type: String
    //     }
    // ],
    phcourse:{
        type: String,
    },
        phgrade:{
            type: String,
        },
        phboard:{
            type: String,
        }, 
        phpassingYear:{
            type: String,
        },
        mpcourse: {
            type: String,
        },
        mpgrade:{
            type: String,
        }, 
        mpboard:{
            type: String,
        }, 
        mppassingYear:{
            type: String,
        },
        mdcourse: {
            type: String,
        },
        mdgrade:{
            type: String,
        },
        mdboard:{
            type: String,
        }, 
        mdpassingYear:{
            type: String,
        },
        bdcourse:{
            type: String,
        },
        bdgrade:{
            type: String,
        },
        bdboard:{
            type: String,
        },
        bdpassingYear:{
            type: String,
        },
        hscourse:{
            type: String,
        },
        hsgrade:{
            type: String,
        },
        hsboard:{
            type: String,
        },
        hspassingYear:{
            type: String,
        }, 
        scourse:{
            type: String,
        },
        sgrade:{
            type: String,
        },
        sboard: {
            type: String,
        },
        spassingYear:{
            type: String,
        },
        ocourse:{
            type: String,
        },
        ograde:{
            type: String,
        },
        oboard: {
            type: String,
        },
        opassingYear:{
            type: String,
        },
        phdAward:{
            type:String
        },
        titleOfPhd:{
            type:String  
        },
        areaOfPhd:{
            type:String
        },
        nameOfEmp:{
            type:String 
        },
        designations:{
            type:String  
        },
        periodFrom:{
            type:String  
        },
        periodTo:{
            type:String  
        },
        grossSalary:{
            type:String    
        },
        responsibility:{
            type:String  
        },
        externalDesp:{
            type:String 
        },
        managementDesp:{
            type:String 
        },
         professionalDesp:{
            type:String 
        },
        sNo: {
            type: String,
            
        },
        titleOfPaper: {
            type: String,
        },
        nameofJournal: { 
            type: String,
        },
        authorOrCoauthor:{
            type: String, 
        },
        nameofPublisher:{
            type: String, 
        },
        referredorNonreferred:{
            type: String, 
        },
        date: {
            type: String,
        },
        sciEsciScopusUGCCare:{
            type:String
        },
        isbnISSNNo:{
            type:String 
        },
        mTechresearchNoOfStudent:{
            type:String 
        },
        mTechresearchProcesss:{
            type:String
        },
        mTechresearchAwarded:{
            type:String
        },
        phdresearchNoOfStudent:{
            type:String 
        },
        phdresearchProcesss:{
            type:String
        },
        phdresearchAwarded:{
            type:String
        },
        sponsorningAgenct:{
            type:String
        },
        researchtitle:{
            type:String 
        },
        researchStatus:{
            type:String
        },
        researchBudget:{
            type:String
        },
        mTechresearchClg:{
            type:String
        },
        phdresearchClg:{
            type:String
        },
        titleSubject:{
            type:String
        },
        conferenceTitle:{
            type:String
        },
        sponsorningInst:{
            type:String
        },
        place:{
            type:String 
        },
        monthYear:{
            type:String  
        },
        publishedInJournal:{
            type:String    
        },
        booktittle: {
            type: String,
        },
        publisher: { 
            type: String,
        },
    
        status: {
            type: String,
        },
        publishDate:{
            type: String,  
        },
        application:{
            type: String, 
        },
        topic:{
            type: String,
        },
        pstatus:{
            type: String,
        },
        attendTitle:{
            type: String,
        },
        attendnamePlaceInst:{
            type: String,
        },
        attendlectureDate:{
            type: String,
        },
        attendduration:{
            type: String,
        },
        organizedTitle:{
            type: String,
        },
        organizednamePlaceInst:{
            type: String,
        },
        organizedLectureDate:{
            type: String,
        },
        organizedDuration:{
            type: String,
        },
        webinarTitle:{
            type: String,
        },
        webinarnamePlaceInst:{
            type: String,
        },
        webinarLectureDate:{
            type: String,
        },
        webinarDuration:{
            type: String,
        },
        titleOfShow:{
            type: String, 
        },
        companyName:{
            type: String,   
        },
        categorization:{
            type: String,   
        },
        soloArtist:{
            type: String, 
        },
        refreeName:{
            type: String,
        },
        refreeCollege:{
            type: String,
        },
        refreeDesignation:{
            type: String,
        },
        refreeAdd:{
            type: String,
        },
        refreeEmail:{
            type: String,
        },
        refreeMob:{
            type: String, 
        },
        refreeRecom:{
            type: String,  
        }


    

})


prosonalSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

prosonalSchema.set('toJSON', {
    virtuals: true,
});

exports.Personal = mongoose.model('Personal', prosonalSchema);
