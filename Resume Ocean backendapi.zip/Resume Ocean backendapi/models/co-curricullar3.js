const mongoose = require('mongoose');

const coCurricularSchema3 = mongoose.Schema({
    

    organizationName: {
        type: String,
        
    },
    membershipType: {
        type: String,
        
    },
    periodFrom:{
        type: String,
    },
    PeriodTo:{
        type: String, 
    },
    positionDesignation:{
        type: String,  
    }
   

})


coCurricularSchema3.virtual('id').get(function () {
    return this._id.toHexString();
});

coCurricularSchema3.set('toJSON', {
    virtuals: true,
});

exports.CoCurricullar3 = mongoose.model('CoCurricullar3', coCurricularSchema3);
