const mongoose = require('mongoose');

const employmenntSchema = mongoose.Schema({
    
   
    nameOfEmployer: {
        type: String,
        
    },
    postDesignation: {
        type: String,
        
    },
    periodOfEmploymentFrom:{
        type: String,
    },
    periodOfEmploymentTo:{
        type: String, 
    },
    grossSalary:{
        type: String,  
    },
    responsibilities:{
        type: String,  
    },
   

})


employmenntSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

employmenntSchema.set('toJSON', {
    virtuals: true,
});

exports.Employment = mongoose.model('Employment', employmenntSchema);
