const mongoose = require('mongoose');

const educationSchema = mongoose.Schema({
        sNo:String,
        degree:String,
        course:String,
        marks:String,
        boardsName:String, 
        yearOfPass:String,  
        phdAwarded:String,  
        titleofPhD:String, 
        specializationPhD:String,

})


educationSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

educationSchema.set('toJSON', {
    virtuals: true,
});

exports.Education = mongoose.model('Education', educationSchema);
