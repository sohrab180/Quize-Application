const mongoose = require('mongoose');

const addressSchema = mongoose.Schema({
    addres: {
        type: String,
        
    },
    city: {
        type: String,
    },
    state: { 
        type: String,
    },

    postcode: {
        type: String,
    }

})


addressSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

addressSchema.set('toJSON', {
    virtuals: true,
});

exports.Address = mongoose.model('Address', addressSchema);
