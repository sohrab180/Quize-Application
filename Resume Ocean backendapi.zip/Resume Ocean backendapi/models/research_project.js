const mongoose = require('mongoose');

const rProjectSchema = mongoose.Schema({
    associated: {
        type: String,
    },
    sponsoringAgency: { 
        type: String,
    },
    title:{
        type: String, 
    },
    status:{
        type: String, 
    },
    noMastersAwarded: { 
        type: String,
    },
    noPhDAwarded:{
        type: String, 
    },
    noPublications:{
        type: String, 
    },
    noPatent:{
        type: String, 
    },
    budget:{
        type: String,   
    }

})
rProjectSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

rProjectSchema.set('toJSON', {
    virtuals: true,
});

exports.Rproject = mongoose.model('Rproject', rProjectSchema);
