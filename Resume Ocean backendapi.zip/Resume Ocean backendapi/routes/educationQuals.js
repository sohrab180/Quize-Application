const {Education} = require('../models/educationQual');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const educationList = await Education.find();

    if(!educationList) {
        res.status(500).json({success: false})
    } 
    return res.status(200).send(educationList);
})

router.get('/:id', async(req,res)=>{
    const education = await Education.findById(req.params.id);

    if(!education) {
         return res.status(500).json({message: 'The education with the given ID was not found.'})
    } 
    return res.status(200).send(education);
})



router.post('/', async (req,res)=>{
    let education = new Education({
        sNo: req.body.sNo,
            degree: req.body.degree,
            course: req.body.course,
            marks: req.body.marks,
            boardsName: req.body.boardsName,
            yearOfPass: req.body.yearOfPass,
            phdAwarded: req.body.phdAwarded,
            titleofPhD: req.body.titleofPhD,
            specializationPhD: req.body.specializationPhD,
    })
    education = await education.save();

    if(!education)
    return res.status(400).send('the education cannot be created!')

    res.send(education);
})


router.put('/:id',async (req, res)=> {
    const education = await Education.findByIdAndUpdate(
        req.params.id,
        {
                sNo: req.body.sNo,
                degree: req.body.degree,
                course: req.body.course,
                marks: req.body.marks,
                boardsName: req.body.boardsName,
                yearOfPass: req.body.yearOfPass,
                phdAwarded: req.body.phdAwarded,
                titleofPhD: req.body.titleofPhD,
                specializationPhD: req.body.specializationPhD,

            
        },
        { new: true}
    )

    if(!education)
    return res.status(400).send('the education cannot be created!')

    res.send(education);
})

router.delete('/:id', (req, res)=>{
    Education.findByIdAndRemove(req.params.id).then(education =>{
        if(education) {
            return res.status(200).json({success: true, message: 'the education is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "education not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;