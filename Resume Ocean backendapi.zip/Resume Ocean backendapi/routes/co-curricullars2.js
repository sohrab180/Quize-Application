const {CoCurricullar2} = require('../models/co-curricullar2');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const coCurricullar2List = await CoCurricullar2.find();

    if(!coCurricullar2List) {
        res.status(500).json({success: false})
    } 
    return res.status(200).send(coCurricullar2List);
})

router.get('/:id', async(req,res)=>{
    const coCurricullar2 = await CoCurricullar2.findById(req.params.id);

    if(!coCurricullar2) {
         return res.status(500).json({message: 'The coCurricullar2 with the given ID was not found.'})
    } 
    return res.status(200).send(coCurricullar2);
})



router.post('/', async (req,res)=>{
    let coCurricullar2 = new CoCurricullar2({
        instName: req.body.instName,
        degree: req.body.degree,
        responsibilities: req.body.responsibilities,
        periodFrom: req.body.periodFrom,
        periodTo: req.body.periodTo,
    })
    coCurricullar2 = await coCurricullar2.save();

    if(!coCurricullar2)
    return res.status(400).send('the coCurricullar2 cannot be created!')

    res.send(coCurricullar2);
})


router.put('/:id',async (req, res)=> {
    const coCurricullar2 = await CoCurricullar2.findByIdAndUpdate(
        req.params.id,
        {
            instName: req.body.instName,
        degree: req.body.degree,
        responsibilities: req.body.responsibilities,
        periodFrom: req.body.periodFrom,
        periodTo: req.body.periodTo,
            
        },
        { new: true}
    )

    if(!coCurricullar2)
    return res.status(400).send('the coCurricullar2 cannot be created!')

    res.send(coCurricullar2);
})

router.delete('/:id', (req, res)=>{
    CoCurricullar2.findByIdAndRemove(req.params.id).then(coCurricullar2 =>{
        if(coCurricullar2) {
            return res.status(200).json({success: true, message: 'the coCurricullar2 is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "coCurricullar2 not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;