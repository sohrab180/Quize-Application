const {Journal} = require('../models/journal');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const journalList = await Journal.find();

    if(!journalList) {
        res.status(500).json({success: false})
    } 
   return res.status(200).send(journalList);
})

router.get('/:id', async(req,res)=>{
    const journal = await Journal.findById(req.params.id);

    if(!journal) {
        res.status(500).json({message: 'The Journal with the given ID was not found.'})
    } 
   return res.status(200).send(journal);
})



router.post('/', async (req,res)=>{
    let journal = new Journal({
        publicationType: req.body.publicationType,
        nameOfJournal: req.body.nameOfJournal,
        titleOfArticle: req.body.titleOfArticle,
        volume:req.body.volume,
        whetherSoleAuthor:req.body.whetherSoleAuthor,
        nameOfPublisher: req.body.nameOfPublisher,
        monthYearOfpublication: req.body.monthYearOfpublication,
        referred: req.body.referred,
        indexing: req.body.indexing,
        isbn: req.body.isbn
    })
    journal = await journal.save();

    if(!journal)
    return res.status(400).send('the journal cannot be created!')

    res.send(journal);
});


router.put('/:id',async (req, res)=> {
    const journal = await Journal.findByIdAndUpdate(
        req.params.id,
        {
            publicationType: req.body.publicationType,
        nameOfJournal: req.body.nameOfJournal,
        titleOfArticle: req.body.titleOfArticle,
        volume:req.body.volume,
        whetherSoleAuthor:req.body.whetherSoleAuthor,
        nameOfPublisher: req.body.nameOfPublisher,
        monthYearOfpublication: req.body.monthYearOfpublication,
        referred: req.body.referred,
        indexing: req.body.indexing,
        isbn: req.body.isbn
        },
        { new: true}
    )

    if(!journal)
    return res.status(400).send('the journal cannot be created!')

    res.send(journal);
})

router.delete('/:id', (req, res)=>{
    Journal.findByIdAndRemove(req.params.id).then(journal =>{
        if(journal) {
            return res.status(200).json({success: true, message: 'the journal is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "journal not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;