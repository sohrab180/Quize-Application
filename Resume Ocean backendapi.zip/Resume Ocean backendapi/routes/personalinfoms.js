const {Personal} = require('../models/personalinfo');
const express = require('express');
const router = express.Router();
const multer = require('multer');
const mongoose = require('mongoose');


router.get(`/`, async (req, res) =>{
    const personalList = await Personal.find();

    if(!personalList) {
        res.status(500).json({success: false})
    } 
    return  res.status(200).send(personalList);
})

router.get('/:id', async(req,res)=>{
    const personal = await Personal.findById(req.params.id);

    if(!personal) {
        res.status(500).json({message: 'The Personal with the given ID was not found.'})
    } 
    return  res.status(200).send(personal);
})



router.post('/', async (req,res)=>{
    let personal = new Personal({
       
        presentEmp: req.body.presentEmp,
        designation:req.body.designation,
        majorOfArea:req.body.majorOfArea,
       
       
        // image: `${basePath}${fileName}`,
        phcourse:req.body.phcourse,
        phgrade:req.body.phgrade,
        phboard:req.body.phboard,
        phpassingYear:req.body.phpassingYear,
        mpcourse:req.body.mpcourse,
        mpgrade:req.body.mpgrade,
        mpboard:req.body.mpboard,
        mppassingYear:req.body.mppassingYear,
        mdcourse:req.body.mdcourse,
        mdgrade:req.body.mdgrade,
        mdboard:req.body.mdboard,
        mdpassingYear:req.body.mdpassingYear,
        bdcourse:req.body.bdcourse,
        bdgrade:req.body.bdgrade,
        bdboard:req.body.bdboard,
        bdpassingYear:req.body.bdpassingYear,
        hscourse:req.body.hscourse,
        hsgrade:req.body.hsgrade,
        hsboard:req.body.hsboard,
        hspassingYear: req.body.hspassingYear,
        scourse:req.body.scourse,
        sgrade:req.body.sgrade,
        sboard: req.body.sboard,
        spassingYear:req.body.spassingYear,
        ocourse:req.body.ocourse,
        ograde:req.body.ograde,
        oboard: req.body.oboard,
        opassingYear:req.body.opassingYear,
        phdAward:req.body.phdAward,
        titleOfPhd:req.body.titleOfPhd,
        areaOfPhd:req.body.areaOfPhd,
        nameOfEmp:req.body.nameOfEmp,
        designations:req.body.designations,
        periodFrom:req.body.periodFrom,
        periodTo:req.body.periodTo,
        grossSalary:req.body.grossSalary,
        responsibility:req.body.responsibility,
        externalDesp:req.body.externalDesp,
        managementDesp:req.body.managementDesp,
         professionalDesp:req.body.professionalDesp,
         sNo: req.body.sNo,
         titleOfPaper: req.body.titleOfPaper,
         nameofJournal: req.body.nameofJournal,
         authorOrCoauthor:req.body.authorOrCoauthor,
         nameofPublisher:req.body.nameofPublisher,
         referredorNonreferred: req.body.referredorNonreferred,
         date: req.body.date,
         sciEsciScopusUGCCare: req.body.sciEsciScopusUGCCare,
         isbnISSNNo: req.body.isbnISSNNo,
         mTechresearchNoOfStudent:req.body.mTechresearchNoOfStudent,
        mTechresearchProcesss:req.body.mTechresearchProcesss,
        mTechresearchAwarded:req.body.mTechresearchAwarded,
        mTechresearchClg:req.body.mTechresearchClg,
        phdresearchNoOfStudent:req.body.phdresearchNoOfStudent,
        phdresearchProcesss:req.body.phdresearchProcesss,
        phdresearchAwarded:req.body.phdresearchAwarded,
        phdresearchClg:req.body.phdresearchClg,
        sponsorningAgenct:req.body.sponsorningAgenct,
        researchtitle:req.body.researchtitle,
        researchStatus:req.body.researchStatus,
        researchBudget:req.body.researchBudget,
        titleSubject:req.body.titleSubject,
        conferenceTitle:req.body.conferenceTitle,
        sponsorningInst:req.body.sponsorningInst,
        place:req.body.place,
        monthYear:req.body.monthYear,
        publishedInJournal:req.body.publishedInJournal,
        booktittle: req.body.booktittle,
        publisher: req.body.publisher,
        status: req.body.status,
        publishDate: req.body.publishDate,
        application: req.body.application,
        topic: req.body.topic,
        pstatus: req.body.pstatus,
        attendTitle:req.body.attendTitle,
        attendnamePlaceInst:req.body.attendnamePlaceInst,
        attendlectureDate:req.body.attendlectureDate,
        attendduration:req.body.attendduration,
        organizedTitle:req.body.organizedTitle,
        organizednamePlaceInst:req.body.organizednamePlaceInst,
        organizedLectureDate:req.body.organizedLectureDate,
        organizedDuration:req.body.organizedDuration,
        webinarTitle:req.body.webinarTitle,
        webinarnamePlaceInst:req.body.webinarnamePlaceInst,
        webinarLectureDate:req.body.webinarLectureDate,
        webinarDuration:req.body.webinarDuration,
        titleOfShow:req.body.titleOfShow,
        companyName:req.body.companyName,
        categorization:req.body.categorization,
        soloArtist:req.body.soloArtist,
        refreeName:req.body.refreeName,
        refreeCollege:req.body.refreeCollege,
        refreeDesignation:req.body.refreeDesignation,
        refreeAdd:req.body.refreeAdd,
        refreeEmail:req.body.refreeEmail,
        refreeMob:req.body.refreeMob,
        refreeRecom:req.body.refreeRecom,


        
    })
    personal = await personal.save();

    if(!personal)
    return res.status(400).send('the personal cannot be created!')

    res.send(personal);
});


router.put('/:id',async (req, res)=> {
    const personal = await Personal.findByIdAndUpdate(
        req.params.id,
        {
            fullname: req.body.fullname,
        dob: req.body.dob,
        fathersname: req.body.fathersname,
        mothersname: req.body.mothersname,
        metrial: req.body.metrial,
        spaousename: req.body.spaousename,
        mobile: req.body.mobile,
        email: req.body.email,
        addres: req.body.addres,
        city: req.body.city,
        state: req.body.state,
        postcode: req.body.postcode,
        paddres: req.body.paddres,
        pcity: req.body.pcity,
        pstate: req.body.pstate,
        ppostcode: req.body.ppostcode,
        pnationality: req.body.pnationality,
        presentEmp: req.body.presentEmp,
        designation:req.body.designation,
        majorOfArea:req.body.majorOfArea,
        ocidId:req.body.ocidId,
        hIndex:req.body.hIndex,
        citationIndex:req.body.citationIndex,
        linkedIn:req.body.linkedIn,
        facebook:req.body.facebook,
        twitter:req.body.twitter,
        instagram:req.body.instagram,
        // image: `${basePath}${fileName}`,
        phcourse:req.body.phcourse,
        phgrade:req.body.phgrade,
        phboard:req.body.phboard,
        phpassingYear:req.body.phpassingYear,
        mpcourse:req.body.mpcourse,
        mpgrade:req.body.mpgrade,
        mpboard:req.body.mpboard,
        mppassingYear:req.body.mppassingYear,
        mdcourse:req.body.mdcourse,
        mdgrade:req.body.mdgrade,
        mdboard:req.body.mdboard,
        mdpassingYear:req.body.mdpassingYear,
        bdcourse:req.body.bdcourse,
        bdgrade:req.body.bdgrade,
        bdboard:req.body.bdboard,
        bdpassingYear:req.body.bdpassingYear,
        hscourse:req.body.hscourse,
        hsgrade:req.body.hsgrade,
        hsboard:req.body.hsboard,
        hspassingYear: req.body.hspassingYear,
        scourse:req.body.scourse,
        sgrade:req.body.sgrade,
        sboard: req.body.sboard,
        spassingYear:req.body.spassingYear,
        ocourse:req.body.ocourse,
        ograde:req.body.ograde,
        oboard: req.body.oboard,
        opassingYear:req.body.opassingYear,
        phdAward:req.body.phdAward,
        titleOfPhd:req.body.titleOfPhd,
        areaOfPhd:req.body.areaOfPhd,
        nameOfEmp:req.body.nameOfEmp,
        designations:req.body.designations,
        periodFrom:req.body.periodFrom,
        periodTo:req.body.periodTo,
        grossSalary:req.body.grossSalary,
        responsibility:req.body.responsibility,
        externalDesp:req.body.externalDesp,
        managementDesp:req.body.managementDesp,
         professionalDesp:req.body.professionalDesp,
         sNo: req.body.sNo,
         titleOfPaper: req.body.titleOfPaper,
         nameofJournal: req.body.nameofJournal,
         authorOrCoauthor:req.body.authorOrCoauthor,
         nameofPublisher:req.body.nameofPublisher,
         referredorNonreferred: req.body.referredorNonreferred,
         date: req.body.date,
         sciEsciScopusUGCCare: req.body.sciEsciScopusUGCCare,
         isbnISSNNo: req.body.isbnISSNNo,
         mTechresearchNoOfStudent:req.body.mTechresearchNoOfStudent,
         mTechresearchProcesss:req.body.mTechresearchProcesss,
         mTechresearchAwarded:req.body.mTechresearchAwarded,
         mTechresearchClg:req.body.mTechresearchClg,
         phdresearchNoOfStudent:req.body.phdresearchNoOfStudent,
         phdresearchProcesss:req.body.phdresearchProcesss,
         phdresearchAwarded:req.body.phdresearchAwarded,
         phdresearchClg:req.body.phdresearchClg,
         sponsorningAgenct:req.body.sponsorningAgenct,
         researchtitle:req.body.researchtitle,
         researchStatus:req.body.researchStatus,
         researchBudget:req.body.researchBudget,
         titleSubject:req.body.titleSubject,
         conferenceTitle:req.body.conferenceTitle,
        sponsorningInst:req.body.sponsorningInst,
        place:req.body.place,
        monthYear:req.body.monthYear,
        publishedInJournal:req.body.publishedInJournal,
        booktittle: req.body.booktittle,
        publisher: req.body.publisher,
        status: req.body.status,
        publishDate: req.body.publishDate,
        application: req.body.application,
        topic: req.body.topic,
        pstatus: req.body.pstatus,
        attendTitle:req.body.attendTitle,
        attendnamePlaceInst:req.body.attendnamePlaceInst,
        attendlectureDate:req.body.attendlectureDate,
        attendduration:req.body.attendduration,
        organizedTitle:req.body.organizedTitle,
        organizednamePlaceInst:req.body.organizednamePlaceInst,
        organizedLectureDate:req.body.organizedLectureDate,
        organizedDuration:req.body.organizedDuration,
        webinarTitle:req.body.webinarTitle,
        webinarnamePlaceInst:req.body.webinarnamePlaceInst,
        webinarLectureDate:req.body.webinarLectureDate,
        webinarDuration:req.body.webinarDuration,
        titleOfShow:req.body.titleOfShow,
        companyName:req.body.companyName,
        categorization:req.body.categorization,
        soloArtist:req.body.soloArtist,
        refreeName:req.body.refreeName,
        refreeCollege:req.body.refreeCollege,
        refreeDesignation:req.body.refreeDesignation,
        refreeAdd:req.body.refreeAdd,
        refreeEmail:req.body.refreeEmail,
        refreeMob:req.body.refreeMob,
        refreeRecom:req.body.refreeRecom,



        },
        { new: true}
    )

    if(!personal)
    return res.status(400).send('the personal cannot be created!')

    res.send(personal);
})

router.delete('/:id', (req, res)=>{
    Personal.findByIdAndRemove(req.params.id).then(personal =>{
        if(personal) {
            return res.status(200).json({success: true, message: 'the personal is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "personal not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;