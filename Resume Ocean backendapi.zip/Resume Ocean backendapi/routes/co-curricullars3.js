const {CoCurricullar3} = require('../models/co-curricullar3');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const coCurricullar3List = await CoCurricullar3.find();

    if(!coCurricullar3List) {
        res.status(500).json({success: false})
    } 
    return res.status(200).send(coCurricullar3List);
})

router.get('/:id', async(req,res)=>{
    const coCurricullar3 = await CoCurricullar3.findById(req.params.id);

    if(!coCurricullar3) {
         return res.status(500).json({message: 'The coCurricullar3 with the given ID was not found.'})
    } 
    return res.status(200).send(coCurricullar3);
})



router.post('/', async (req,res)=>{
    let coCurricullar3 = new CoCurricullar3({
        organizationName: req.body.organizationName,
        membershipType: req.body.membershipType,
        periodFrom: req.body.periodFrom,
        periodTo: req.body.periodTo,
        positionDesignation: req.body.positionDesignation,
    })
    coCurricullar3 = await coCurricullar3.save();

    if(!coCurricullar3)
    return res.status(400).send('the coCurricullar3 cannot be created!')

    res.send(coCurricullar3);
})


router.put('/:id',async (req, res)=> {
    const coCurricullar3 = await CoCurricullar3.findByIdAndUpdate(
        req.params.id,
        {
        organizationName: req.body.organizationName,
        membershipType: req.body.membershipType,
        periodFrom: req.body.periodFrom,
        periodTo: req.body.periodTo,
        positionDesignation: req.body.positionDesignation,
            
        },
        { new: true}
    )

    if(!coCurricullar3)
    return res.status(400).send('the coCurricullar3 cannot be created!')

    res.send(coCurricullar3);
})

router.delete('/:id', (req, res)=>{
    CoCurricullar3.findByIdAndRemove(req.params.id).then(coCurricullar3 =>{
        if(coCurricullar3) {
            return res.status(200).json({success: true, message: 'the coCurricullar3 is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "coCurricullar3 not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;