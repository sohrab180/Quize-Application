const {CoCurricullar1} = require('../models/co-curricullar1');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const coCurricullarList = await CoCurricullar1.find();

    if(!coCurricullarList) {
        res.status(500).json({success: false})
    } 
    return res.status(200).send(coCurricullarList);
})

router.get('/:id', async(req,res)=>{
    const coCurricullar = await CoCurricullar.findById(req.params.id);

    if(!coCurricullar) {
         return res.status(500).json({message: 'The coCurricullar with the given ID was not found.'})
    } 
    return res.status(200).send(coCurricullar);
})



router.post('/', async (req,res)=>{
    let coCurricullar = new CoCurricullar1({
        activityName: req.body.activityName,
        nature: req.body.nature,
        extentionThrough: req.body.extentionThrough,
        monthYear: req.body.monthYear,
        organization: req.body.organization,
    })
    coCurricullar = await coCurricullar.save();

    if(!coCurricullar)
    return res.status(400).send('the coCurricullar cannot be created!')

    res.send(coCurricullar);
})


router.put('/:id',async (req, res)=> {
    const coCurricullar = await CoCurricullar1.findByIdAndUpdate(
        req.params.id,
        {
            activityName: req.body.activityName,
            nature: req.body.nature,
            extentionThrough: req.body.extentionThrough,
            monthYear: req.body.monthYear,
            organization: req.body.organization,
            
        },
        { new: true}
    )

    if(!coCurricullar)
    return res.status(400).send('the coCurricullar cannot be created!')

    res.send(coCurricullar);
})

router.delete('/:id', (req, res)=>{
    CoCurricullar1.findByIdAndRemove(req.params.id).then(coCurricullar =>{
        if(coCurricullar) {
            return res.status(200).json({success: true, message: 'the coCurricullar is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "coCurricullar not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;