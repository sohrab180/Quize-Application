const {Employment} = require('../models/employemnt');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const employmentList = await Employment.find();

    if(!employmentList) {
        res.status(500).json({success: false})
    } 
    return res.status(200).send(employmentList);
})

router.get('/:id', async(req,res)=>{
    const employment = await Employment.findById(req.params.id);

    if(!employment) {
         return res.status(500).json({message: 'The employment with the given ID was not found.'})
    } 
    return res.status(200).send(employment);
})



router.post('/', async (req,res)=>{
    let employment = new Employment({
        nameOfEmployer: req.body.nameOfEmployer,
        postDesignation: req.body.postDesignation,
        periodOfEmploymentFrom: req.body.periodOfEmploymentFrom,
        periodOfEmploymentTo: req.body.periodOfEmploymentTo,
        grossSalary: req.body.grossSalary,
        responsibilities: req.body.responsibilities,
    })
    employment = await employment.save();

    if(!employment)
    return res.status(400).send('the employment cannot be created!')

    res.send(employment);
})


router.put('/:id',async (req, res)=> {
    const employment = await Employment.findByIdAndUpdate(
        req.params.id,
        {
            nameOfEmployer: req.body.nameOfEmployer,
            postDesignation: req.body.postDesignation,
            periodOfEmploymentFrom: req.body.periodOfEmploymentFrom,
            periodOfEmploymentTo: req.body.periodOfEmploymentTo,
            grossSalary: req.body.grossSalary,
            responsibilities: req.body.responsibilities,
            
        },
        { new: true}
    )

    if(!employment)
    return res.status(400).send('the employment cannot be created!')

    res.send(employment);
})

router.delete('/:id', (req, res)=>{
    Employment.findByIdAndRemove(req.params.id).then(employment =>{
        if(employment) {
            return res.status(200).json({success: true, message: 'the employment is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "employment not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;