const {Miscellenous} = require('../models/miscellenouse');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const miscellenousList = await Miscellenous.find();

    if(!miscellenousList) {
        res.status(500).json({success: false})
    } 
   return res.status(200).send(miscellenousList);
})

router.get('/:id', async(req,res)=>{
    const miscellenouse = await Miscellenous.findById(req.params.id);

    if(!miscellenouse) {
        res.status(500).json({message: 'The Miscellenous with the given ID was not found.'})
    } 
     return res.status(200).send(miscellenouse);
})



router.post('/', async (req,res)=>{
    let miscellenouse = new Miscellenous({
        otherRelevant: req.body.otherRelevant,
        name: req.body.name,
        designation:req.body.designation,
        organization: req.body.organization,
        mobile: req.body.mobile,
        email:req.body.email,
    })
    miscellenouse = await miscellenouse.save();

    if(!miscellenouse)
    return res.status(400).send('the miscellenouse cannot be created!')

    res.send(miscellenouse);
});


router.put('/:id',async (req, res)=> {
    const miscellenouse = await Miscellenous.findByIdAndUpdate(
        req.params.id,
        {
        otherRelevant: req.body.otherRelevant,
        name: req.body.name,
        designation:req.body.designation,
        organization: req.body.organization,
        mobile: req.body.mobile,
        email:req.body.email,
        },
        { new: true}
    )

    if(!miscellenouse)
    return res.status(400).send('the miscellenouse cannot be created!')

    res.send(miscellenouse);
})

router.delete('/:id', (req, res)=>{
    Miscellenous.findByIdAndRemove(req.params.id).then(miscellenouse =>{
        if(miscellenouse) {
            return res.status(200).json({success: true, message: 'the miscellenouse is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "miscellenouse not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;