const {Lecture} = require('../models/lectures');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const lectureList = await Lecture.find();

    if(!lectureList) {
        res.status(500).json({success: false})
    } 
   return res.status(200).send(lectureList);
})

router.get('/:id', async(req,res)=>{
    const lecture = await Lecture.findById(req.params.id);

    if(!Lecture) {
        res.status(500).json({message: 'The Lecture with the given ID was not found.'})
    } 
     return res.status(200).send(lecture);
})



router.post('/', async (req,res)=>{
    let lecture = new Lecture({
        titleSubjectLecture: req.body.titleSubjectLecture,
        namePlaceInstitution: req.body.namePlaceInstitution,
        dateLecture:req.body.dateLecture,
        duration:req.body.duration,
    })
    lecture = await lecture.save();

    if(!lecture)
    return res.status(400).send('the lecture cannot be created!')

    res.send(lecture);
});


router.put('/:id',async (req, res)=> {
    const lecture = await Lecture.findByIdAndUpdate(
        req.params.id,
        {
            titleSubjectLecture: req.body.titleSubjectLecture,
            namePlaceInstitution: req.body.namePlaceInstitution,
            dateLecture:req.body.dateLecture,
            duration:req.body.duration,
        },
        { new: true}
    )

    if(!lecture)
    return res.status(400).send('the lecture cannot be created!')

    res.send(lecture);
})

router.delete('/:id', (req, res)=>{
    Lecture.findByIdAndRemove(req.params.id).then(lecture =>{
        if(lecture) {
            return res.status(200).json({success: true, message: 'the lecture is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "lecture not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;