const { Profile } = require('../models/profile');
const express = require('express');
const router = express.Router();

router.get('/:id', async (req, res) => {
    const profileList = await Profile.find();

    if (!profileList) {
        res.status(500).json({ success: false })
    }
    return res.status(200).send(profileList);
});

router.get('/:id', async (req, res) => {
    const profile = await Profile.findById(req.params.id);

    if (!profile) {
        res.status(500).json({ message: 'The Profile with the given ID was not found.' })
    }
    return res.status(200).send(profile);
});



router.post('/', async (req, res) => {
    let profile = new Profile({
        user_id: req.body.user_id,
        fullname: req.body.fullname,
        dob: req.body.dob,
        age: req.body.age,
        fathersname: req.body.fathersname,
        mothersname: req.body.mothersname,
        metrial: req.body.metrial,
        spaousename: req.body.spaousename,
        mobile: req.body.mobile,
        email: req.body.email,
        addres: req.body.addres,
        city: req.body.city,
        state: req.body.state,
        postcode: req.body.postcode,
        paddres: req.body.paddres,
        pcity: req.body.pcity,
        pstate: req.body.pstate,
        ppostcode: req.body.ppostcode,
        pnationality: req.body.pnationality,
        linkedIn: req.body.linkedIn,
        facebook: req.body.facebook,
        twitter: req.body.twitter,
        instagram: req.body.instagram,
        ocidId: req.body.ocidId,
        hIndex: req.body.hIndex,
        citationIndex: req.body.citationIndex,
        summaryDetails:req.body.summaryDetails,
    })
    profile = await profile.save();

    if (!profile)
        return res.status(400).send('the profile cannot be created!')

    res.send(profile);
});


router.put('/:id', async (req, res) => {
    debugger
    const profile = await Profile.findByIdAndUpdate(
        req.params.id,
        {
            user_id: req.body.user_id,
            fullname: req.body.fullname,
            dob: req.body.dob,
            age: req.body.age,
            fathersname: req.body.fathersname,
            mothersname: req.body.mothersname,
            metrial: req.body.metrial,
            spaousename: req.body.spaousename,
            mobile: req.body.mobile,
            email: req.body.email,
            addres: req.body.addres,
            city: req.body.city,
            state: req.body.state,
            postcode: req.body.postcode,
            paddres: req.body.paddres,
            pcity: req.body.pcity,
            pstate: req.body.pstate,
            ppostcode: req.body.ppostcode,
            pnationality: req.body.pnationality,
            linkedIn: req.body.linkedIn,
            facebook: req.body.facebook,
            twitter: req.body.twitter,
            instagram: req.body.instagram,
            ocidId: req.body.ocidId,
            hIndex: req.body.hIndex,
            citationIndex: req.body.citationIndex,
            summaryDetails:req.body.summaryDetails,
        },
        { new: true }
    )

    if (!profile)
        return res.status(400).send('the profile cannot be created!')

    res.send(profile);
})

router.delete('/:id', (req, res) => {
    Profile.findByIdAndRemove(req.params.id).then(profile => {
        if (profile) {
            return res.status(200).json({ success: true, message: 'the profile is deleted!' })
        } else {
            return res.status(404).json({ success: false, message: "profile not found!" })
        }
    }).catch(err => {
        return res.status(500).json({ success: false, error: err })
    })
})

module.exports = router;