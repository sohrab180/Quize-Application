const {Patent} = require('../models/patent');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const patentList = await Patent.find();

    if(!patentList) {
        res.status(500).json({success: false})
    } 
   return res.status(200).send(patentList);
})

router.get('/:id', async(req,res)=>{
    const patent = await Patent.findById(req.params.id);

    if(!patent) {
        res.status(500).json({message: 'The Patent with the given ID was not found.'})
    } 
     return res.status(200).send(patent);
})



router.post('/', async (req,res)=>{
    let patent = new Patent({
        application: req.body.application,
        topic: req.body.topic,
        status:req.body.status,
    })
    patent = await patent.save();

    if(!patent)
    return res.status(400).send('the patent cannot be created!')

    res.send(patent);
});


router.put('/:id',async (req, res)=> {
    const patent = await Patent.findByIdAndUpdate(
        req.params.id,
        {
            application: req.body.application,
            topic: req.body.topic,
            status:req.body.status,
        },
        { new: true}
    )

    if(!patent)
    return res.status(400).send('the patent cannot be created!')

    res.send(patent);
})

router.delete('/:id', (req, res)=>{
    Patent.findByIdAndRemove(req.params.id).then(patent =>{
        if(patent) {
            return res.status(200).json({success: true, message: 'the patent is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "patent not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;