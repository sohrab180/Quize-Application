const {Rguidence} = require('../models/research_guidence');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const rguidenceList = await Rguidence.find();

    if(!rguidenceList) {
        res.status(500).json({success: false})
    } 
   return res.status(200).send(rguidenceList);
})

router.get('/:id', async(req,res)=>{
    const rguidence = await Rguidence.findById(req.params.id);

    if(!rguidence) {
        res.status(500).json({message: 'The Rguidence with the given ID was not found.'})
    } 
     return res.status(200).send(rguidence);
})



router.post('/', async (req,res)=>{
    let rguidence = new Rguidence({
        nameScholar: req.body.nameScholar,
        nameDegree: req.body.nameDegree,
        typeGuidence:req.body.typeGuidence,
        status: req.body.status,
        instituteName: req.body.instituteName,
        typeWork:req.body.typeWork,
        yearAwarded:req.body.yearAwarded,
    })
    rguidence = await rguidence.save();

    if(!rguidence)
    return res.status(400).send('the rguidence cannot be created!')

    res.send(rguidence);
});


router.put('/:id',async (req, res)=> {
    const rguidence = await Rguidence.findByIdAndUpdate(
        req.params.id,
        {
            nameScholar: req.body.nameScholar,
        nameDegree: req.body.nameDegree,
        typeGuidence:req.body.typeGuidence,
        status: req.body.status,
        instituteName: req.body.instituteName,
        typeWork:req.body.typeWork,
        yearAwarded:req.body.yearAwarded,
        },
        { new: true}
    )

    if(!rguidence)
    return res.status(400).send('the rguidence cannot be created!')

    res.send(rguidence);
})

router.delete('/:id', (req, res)=>{
    Rguidence.findByIdAndRemove(req.params.id).then(rguidence =>{
        if(rguidence) {
            return res.status(200).json({success: true, message: 'the rguidence is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "rguidence not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;