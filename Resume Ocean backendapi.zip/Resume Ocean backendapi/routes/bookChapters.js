const {Bookchapter} = require('../models/bookChapter');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const bookChapterList = await Bookchapter.find();

    if(!bookChapterList) {
        res.status(500).json({success: false})
    } 
    return res.status(200).send(bookChapterList);
})

router.get('/:id', async(req,res)=>{
    const bookChapter = await Bookchapter.findById(req.params.id);

    if(!bookChapter) {
        res.status(500).json({message: 'The Bookchapter with the given ID was not found.'})
    } 
    return res.status(200).send(bookChapter);
})



router.post('/', async (req,res)=>{
    let bookChapter = new Bookchapter({
        sNo: req.body.sNo,
        booktittle: req.body.booktittle,
        publisher: req.body.publisher,
        status: req.body.status
    })
    bookChapter = await bookChapter.save();

    if(!bookChapter)
    return res.status(400).send('the bookChapter cannot be created!')

    res.send(bookChapter);
});


router.put('/:id',async (req, res)=> {
    const bookChapter = await Bookchapter.findByIdAndUpdate(
        req.params.id,
        {
            sNo: req.body.sNo,
            booktittle: req.body.booktittle,
            publisher: req.body.publisher,
            status: req.body.status
        },
        { new: true}
    )

    if(!bookChapter)
    return res.status(400).send('the bookChapter cannot be created!')

    res.send(bookChapter);
})

router.delete('/:id', (req, res)=>{
    Bookchapter.findByIdAndRemove(req.params.id).then(bookChapter =>{
        if(bookChapter) {
            return res.status(200).json({success: true, message: 'the bookChapter is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "bookChapter not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;