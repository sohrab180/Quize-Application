const {Conference} = require('../models/conference');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const conferenceList = await Conference.find();

    if(!conferenceList) {
        res.status(500).json({success: false})
    } 
    return res.status(200).send(conferenceList);
})

router.get('/:id', async(req,res)=>{
    const conference = await Conference.findById(req.params.id);

    if(!conference) {
        res.status(500).json({message: 'The Conference with the given ID was not found.'})
    } 
   return  res.status(200).send(conference);
})



router.post('/', async (req,res)=>{
    let conference = new Conference({
        nameCourseCertificationWorkshopConferences: req.body.nameCourseCertificationWorkshopConferences,
        eventType: req.body.eventType,
        attendOrganized: req.body.attendOrganized,
        sponsoringInstitution: req.body.sponsoringInstitution,
        periodFrom: req.body.periodFrom,
        periodTo: req.body.periodTo
    })
    conference = await conference.save();

    if(!conference)
    return res.status(400).send('the conference cannot be created!')

    res.send(conference);
});


router.put('/:id',async (req, res)=> {
    const conference = await Conference.findByIdAndUpdate(
        req.params.id,
        {
            nameCourseCertificationWorkshopConferences: req.body.nameCourseCertificationWorkshopConferences,
            eventType: req.body.eventType,
            attendOrganized: req.body.attendOrganized,
            sponsoringInstitution: req.body.sponsoringInstitution,
            periodFrom: req.body.periodFrom,
            periodTo: req.body.periodTo
        },
        { new: true}
    )

    if(!conference)
    return res.status(400).send('the conference cannot be created!')

    res.send(conference);
})

router.delete('/:id', (req, res)=>{
    Conference.findByIdAndRemove(req.params.id).then(conference =>{
        if(conference) {
            return res.status(200).json({success: true, message: 'the conference is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "conference not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;