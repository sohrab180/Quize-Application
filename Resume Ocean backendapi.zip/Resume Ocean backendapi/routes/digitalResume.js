const { DigitalResume } = require('../models/digitalResume');
const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const jsonParser = bodyParser.json();

router.get(`/`, async (req, res) => {
    const dataList = await DigitalResume.find();

    if (!dataList) {
        res.status(500).json({ success: false })
    }
    return res.status(200).send(dataList);
})

router.get('/:id', async (req, res) => {
    const data = await DigitalResume.findById(req.params.id);

    if (!data) {
        return res.status(500).json({ message: 'The data with the given ID was not found.' })
    }
    return res.status(200).send(data);
})

router.post('/', jsonParser, (req, res) => {
    console.log(req.body);
    const data = new DigitalResume({
        profile: {
            user_id: req.body.user_id,
            fullname: req.body.fullname,
            dob: req.body.dob,
            age: req.body.age,
            fathersname: req.body.fathersname,
            mothersname: req.body.mothersname,
            metrial: req.body.metrial,
            spaousename: req.body.spaousename,
            mobile: req.body.mobile,
            email: req.body.email,
            addres: req.body.addres,
            city: req.body.city,
            state: req.body.state,
            postcode: req.body.postcode,
            paddres: req.body.paddres,
            pcity: req.body.pcity,
            pstate: req.body.pstate,
            ppostcode: req.body.ppostcode,
            pnationality: req.body.pnationality,
            linkedIn: req.body.linkedIn,
            facebook: req.body.facebook,
            twitter: req.body.twitter,
            instagram: req.body.instagram,
            ocidId: req.body.ocidId,
            hIndex: req.body.hIndex,
            citationIndex: req.body.citationIndex,
            summaryDetails: req.body.summaryDetails,
        },
        educaion: {
            sNo: req.body.sNo,
            degree: req.body.degree,
            course: req.body.course,
            marks: req.body.marks,
            boardsName: req.body.boardsName,
            yearOfPass: req.body.yearOfPass,
            phdAwarded: req.body.phdAwarded,
            titleofPhD: req.body.titleofPhD,
            specializationPhD: req.body.specializationPhD,
        },
        book: {
            sNo: req.body.sNo,
            application: req.body.application,
            topic: req.body.topic,
            status: req.body.status
        },
        co_curricullar1: {
            activityName: req.body.activityName,
            nature: req.body.nature,
            extentionThrough: req.body.extentionThrough,
            monthYear: req.body.monthYear,
            organization: req.body.organization,
        },
        conference: {
            nameCourseCertificationWorkshopConferences: req.body.nameCourseCertificationWorkshopConferences,
            eventType: req.body.eventType,
            attendOrganized: req.body.attendOrganized,
            sponsoringInstitution: req.body.sponsoringInstitution,
            periodFrom: req.body.periodFrom,
            periodTo: req.body.periodTo
        },
        employement: {
            nameOfEmployer: req.body.nameOfEmployer,
            postDesignation: req.body.postDesignation,
            periodOfEmploymentFrom: req.body.periodOfEmploymentFrom,
            periodOfEmploymentTo: req.body.periodOfEmploymentTo,
            grossSalary: req.body.grossSalary,
            responsibilities: req.body.responsibilities,
        },
        journal: {
            publicationType: req.body.publicationType,
            nameOfJournal: req.body.nameOfJournal,
            titleOfArticle: req.body.titleOfArticle,
            volume: req.body.volume,
            whetherSoleAuthor: req.body.whetherSoleAuthor,
            nameOfPublisher: req.body.nameOfPublisher,
            monthYearOfpublication: req.body.monthYearOfpublication,
            referred: req.body.referred,
            indexing: req.body.indexing,
            isbn: req.body.isbn
        },
        lecture: {
            titleSubjectLecture: req.body.titleSubjectLecture,
            namePlaceInstitution: req.body.namePlaceInstitution,
            dateLecture: req.body.dateLecture,
            duration: req.body.duration,
        },
        miscellenous: {
            otherRelevant: req.body.otherRelevant,
            name: req.body.name,
            designation: req.body.designation,
            organization: req.body.organization,
            mobile: req.body.mobile,
            email: req.body.email,
        },
        patents: {
            application: req.body.application,
            topic: req.body.topic,
            status: req.body.status,
        },
        presentation: {
            titleSubjectpresented: req.body.titleSubjectpresented,
            subjectSeminar: req.body.subjectSeminar,
            organizingInstitutioName: req.body.organizingInstitutioName,
            durationFrom: req.body.durationFrom,
            durationTo: req.body.durationTo,
            whetherProceedingsPublished: req.body.whetherProceedingsPublished,
        },
        researchGuidence: {
            nameScholar: req.body.nameScholar,
            nameDegree: req.body.nameDegree,
            typeGuidence: req.body.typeGuidence,
            status: req.body.status,
            instituteName: req.body.instituteName,
            typeWork: req.body.typeWork,
            yearAwarded: req.body.yearAwarded,
        },
        researchProject: {
            associated: req.body.associated,
            sponsoringAgency: req.body.sponsoringAgency,
            title: req.body.title,
            status: req.body.status,
            noMastersAwarded: req.body.noMastersAwarded,
            noPhDAwarded: req.body.noPhDAwarded,
            noPublications: req.body.noPublications,
            noPatent: req.body.noPatent,
            budget: req.body.budget,
        }
    })
    // education = await education.save();

    // if(!education)
    // return res.status(400).send('the education cannot be created!')

    // res.send(education);

    data.save().then((result) => {
        console.log(result);
        return res.json("dataposted");
    })
        .catch((e) => {
            console.log(e);
        })
})


router.put('/:id', async (req, res) => {
    const data = await DigitalResume.findByIdAndUpdate(
        req.params.id,
        {
            profile: {

                fullname: req.body.fullname,
                dob: req.body.dob,
                age: req.body.age,
                fathersname: req.body.fathersname,
                mothersname: req.body.mothersname,
                metrial: req.body.metrial,
                spaousename: req.body.spaousename,
                mobile: req.body.mobile,
                email: req.body.email,
                addres: req.body.addres,
                city: req.body.city,
                state: req.body.state,
                postcode: req.body.postcode,
                paddres: req.body.paddres,
                pcity: req.body.pcity,
                pstate: req.body.pstate,
                ppostcode: req.body.ppostcode,
                pnationality: req.body.pnationality,
                linkedIn: req.body.linkedIn,
                facebook: req.body.facebook,
                twitter: req.body.twitter,
                instagram: req.body.instagram,
                ocidId: req.body.ocidId,
                hIndex: req.body.hIndex,
                citationIndex: req.body.citationIndex,
                summaryDetails: req.body.summaryDetails,
            },
            educaion: {
                sNo: req.body.sNo,
                degree: req.body.degree,
                course: req.body.course,
                marks: req.body.marks,
                boardsName: req.body.boardsName,
                yearOfPass: req.body.yearOfPass,
                phdAwarded: req.body.phdAwarded,
                titleofPhD: req.body.titleofPhD,
                specializationPhD: req.body.specializationPhD,
            },
            book: {
                sNo: req.body.sNo,
                application: req.body.application,
                topic: req.body.topic,
                status: req.body.status
            },
            co_curricullar1: {
                activityName: req.body.activityName,
                nature: req.body.nature,
                extentionThrough: req.body.extentionThrough,
                monthYear: req.body.monthYear,
                organization: req.body.organization,
            },
            conference: {
                nameCourseCertificationWorkshopConferences: req.body.nameCourseCertificationWorkshopConferences,
                eventType: req.body.eventType,
                attendOrganized: req.body.attendOrganized,
                sponsoringInstitution: req.body.sponsoringInstitution,
                periodFrom: req.body.periodFrom,
                periodTo: req.body.periodTo
            },
            employement: {
                nameOfEmployer: req.body.nameOfEmployer,
                postDesignation: req.body.postDesignation,
                periodOfEmploymentFrom: req.body.periodOfEmploymentFrom,
                periodOfEmploymentTo: req.body.periodOfEmploymentTo,
                grossSalary: req.body.grossSalary,
                responsibilities: req.body.responsibilities,
            },
            journal: {
                publicationType: req.body.publicationType,
                nameOfJournal: req.body.nameOfJournal,
                titleOfArticle: req.body.titleOfArticle,
                volume: req.body.volume,
                whetherSoleAuthor: req.body.whetherSoleAuthor,
                nameOfPublisher: req.body.nameOfPublisher,
                monthYearOfpublication: req.body.monthYearOfpublication,
                referred: req.body.referred,
                indexing: req.body.indexing,
                isbn: req.body.isbn
            },
            lecture: {
                titleSubjectLecture: req.body.titleSubjectLecture,
                namePlaceInstitution: req.body.namePlaceInstitution,
                dateLecture: req.body.dateLecture,
                duration: req.body.duration,
            },
            miscellenous: {
                otherRelevant: req.body.otherRelevant,
                name: req.body.name,
                designation: req.body.designation,
                organization: req.body.organization,
                mobile: req.body.mobile,
                email: req.body.email,
            },
            patents: {
                application: req.body.application,
                topic: req.body.topic,
                status: req.body.status,
            },
            presentation: {
                titleSubjectpresented: req.body.titleSubjectpresented,
                subjectSeminar: req.body.subjectSeminar,
                organizingInstitutioName: req.body.organizingInstitutioName,
                durationFrom: req.body.durationFrom,
                durationTo: req.body.durationTo,
                whetherProceedingsPublished: req.body.whetherProceedingsPublished,
            },
            researchGuidence: {
                nameScholar: req.body.nameScholar,
                nameDegree: req.body.nameDegree,
                typeGuidence: req.body.typeGuidence,
                status: req.body.status,
                instituteName: req.body.instituteName,
                typeWork: req.body.typeWork,
                yearAwarded: req.body.yearAwarded,
            },
            researchProject: {
                associated: req.body.associated,
                sponsoringAgency: req.body.sponsoringAgency,
                title: req.body.title,
                status: req.body.status,
                noMastersAwarded: req.body.noMastersAwarded,
                noPhDAwarded: req.body.noPhDAwarded,
                noPublications: req.body.noPublications,
                noPatent: req.body.noPatent,
                budget: req.body.budget,
            }

        },
        { new: true }
    )

    if (!data)
        return res.status(400).send('the data cannot be created!')

    res.send(data);
})

router.delete('/:id', (req, res) => {
    DigitalResume.findByIdAndRemove(req.params.id).then(data => {
        if (data) {
            return res.status(200).json({ success: true, message: 'the data is deleted!' })
        } else {
            return res.status(404).json({ success: false, message: "data not found!" })
        }
    }).catch(err => {
        return res.status(500).json({ success: false, error: err })
    })
})

module.exports = router;