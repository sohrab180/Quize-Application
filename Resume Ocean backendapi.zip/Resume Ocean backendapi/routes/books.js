const {Book} = require('../models/book');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const bookList = await Book.find();

    if(!bookList) {
        res.status(500).json({success: false})
    } 
    return res.status(200).send(bookList);
})

router.get('/:id', async(req,res)=>{
    const book = await Book.findById(req.params.id);

    if(!book) {
        res.status(500).json({message: 'The Book with the given ID was not found.'})
    } 
    return res.status(200).send(book);
})



router.post('/', async (req,res)=>{
    let book = new Book({
        sNo: req.body.sNo,
        application: req.body.application,
        topic: req.body.topic,
        status: req.body.status
    })
    book = await book.save();

    if(!book)
    return res.status(400).send('the book cannot be created!')

    res.send(book);
});


router.put('/:id',async (req, res)=> {
    const book = await Book.findByIdAndUpdate(
        req.params.id,
        {
            sNo: req.body.sNo,
            application: req.body.application,
            topic: req.body.topic,
            status: req.body.status
        },
        { new: true}
    )

    if(!book)
    return res.status(400).send('the book cannot be created!')

    res.send(book);
})

router.delete('/:id', (req, res)=>{
    Book.findByIdAndRemove(req.params.id).then(book =>{
        if(book) {
            return res.status(200).json({success: true, message: 'the book is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "book not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;