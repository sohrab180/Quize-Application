const { ProfilePic } = require('../models/profilePic');
const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const multer = require('multer');

const FILE_TYPE_MAP = {
    'image/png': 'png',
    'image/jpeg': 'jpeg',
    'image/jpg': 'jpg',
 
};

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const isValid = FILE_TYPE_MAP[file.mimetype];
        let uploadError = new Error('invalid image type');

        if (isValid) {
            uploadError = null;
        }
        cb(uploadError, 'public/userImages');
    },
    filename: function (req, file, cb) {
        const fileName = file.originalname.split(' ').join('-');
        const extension = FILE_TYPE_MAP[file.mimetype];
        cb(null, `${fileName}-${Date.now()}.${extension}`);
    }
});

const uploadOptions = multer({ storage: storage });


router.get(`/`, async (req, res) => {
    const profilePicList = await ProfilePic.find();

    if (!profilePicList) {
        res.status(500).json({ success: false })
    }
    return res.status(200).send(profilePicList);
})

router.get('/:id', async (req, res) => {
    const profilePic = await ProfilePic.findById(req.params.id);

    if (!profilePic) {
        res.status(500).json({ message: 'The profilePic with the given ID was not found.' })
    }
    return res.status(200).send(profilePic);
});
// user_routes.get('/register',userController.loadRegister);
// user_routes.post('/register',upload.single('image'),userController.insertUser);

router.post('/:id', uploadOptions.single('image'), async (req, res) => {
    const file = req.file;
    if (!file) return res.status(400).send('No image in the request');

    const fileName = file.filename;
    const basePath = `${req.protocol}://${req.get('host')}/public/userImages/`;

    let profilePic = new ProfilePic({
        image: `${basePath}${fileName}` // "http://localhost:3000/public/upload/image-2323232"
    });

    profilePic = await profilePic.save();

    if (!profilePic) return res.status(500).send('The upload pic cannot be created');

    res.send(profilePic);
});

router.delete('/:id', (req, res) => {
    ProfilePic.findByIdAndRemove(req.params.id)
        .then((profilePic) => {
            if (profilePic) {
                return res.status(200).json({
                    success: true,
                    message: 'the profilePic is deleted!'
                });
            } else {
                return res.status(404).json({ success: false, message: 'profilePic not found!' });
            }
        })
        .catch((err) => {
            return res.status(500).json({ success: false, error: err });
        });
});


router.put('/gallery-images/:id', uploadOptions.array('images', 10), async (req, res) => {
    const files = req.files;
    let imagesPaths = [];
    const basePath = `${req.protocol}://${req.get('host')}/public/userImages/`;

    if (files) {
        files.map((file) => {
            imagesPaths.push(`${basePath}${file.filename}`);
        });
    }

    const profilePic = await ProfilePic.findByIdAndUpdate(
        req.params.id,
        {
            images: imagesPaths
        },
        { new: true }
    );

    if (!profilePic) return res.status(500).send('the gallery cannot be updated!');

    res.send(profilePic);
});

module.exports = router;