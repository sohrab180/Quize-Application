const {Rproject} = require('../models/research_project');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const rprojectList = await Rproject.find();

    if(!rprojectList) {
        res.status(500).json({success: false})
    } 
   return res.status(200).send(rprojectList);
})

router.get('/:id', async(req,res)=>{
    const rproject = await Rproject.findById(req.params.id);

    if(!rproject) {
        res.status(500).json({message: 'The Rproject with the given ID was not found.'})
    } 
     return res.status(200).send(rproject);
})



router.post('/', async (req,res)=>{
    let rproject = new Rproject({
        associated: req.body.associated,
        sponsoringAgency: req.body.sponsoringAgency,
        title:req.body.title,
        status: req.body.status,
        noMastersAwarded: req.body.noMastersAwarded,
        noPhDAwarded:req.body.noPhDAwarded,
        noPublications:req.body.noPublications,
        noPatent:req.body.noPatent,
        budget:req.body.budget,
    })
    rproject = await rproject.save();

    if(!rproject)
    return res.status(400).send('the rproject cannot be created!')

    res.send(rproject);
});


router.put('/:id',async (req, res)=> {
    const rproject = await Rproject.findByIdAndUpdate(
        req.params.id,
        {
            associated: req.body.associated,
            sponsoringAgency: req.body.sponsoringAgency,
            title:req.body.title,
            status: req.body.status,
            noMastersAwarded: req.body.noMastersAwarded,
            noPhDAwarded:req.body.noPhDAwarded,
            noPublications:req.body.noPublications,
            noPatent:req.body.noPatent,
            budget:req.body.budget,
        },
        { new: true}
    )

    if(!rproject)
    return res.status(400).send('the rproject cannot be created!')

    res.send(rproject);
})

router.delete('/:id', (req, res)=>{
    Rproject.findByIdAndRemove(req.params.id).then(rproject =>{
        if(rproject) {
            return res.status(200).json({success: true, message: 'the rproject is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "rproject not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;