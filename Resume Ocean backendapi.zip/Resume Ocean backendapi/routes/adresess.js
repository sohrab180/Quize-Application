const {Address} = require('../models/address');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const addressList = await Address.find();

    if(!addressList) {
        res.status(500).json({success: false})
    } 
    return res.status(200).send(addressList);
})

router.get('/:id', async(req,res)=>{
    const address = await Address.findById(req.params.id);

    if(!address) {
        res.status(500).json({message: 'The Address with the given ID was not found.'})
    } 
    return res.status(200).send(address);
})



router.post('/', async (req,res)=>{
    let address = new Address({
        addres: req.body.address,
        city: req.body.city,
        state: req.body.state,
        postcode: req.body.postcode
    })
    address = await address.save();

    if(!address)
    return res.status(400).send('the address cannot be created!')

    res.send(address);
});


router.put('/:id',async (req, res)=> {
    const address = await Address.findByIdAndUpdate(
        req.params.id,
        {
        addres: req.body.address,
        city: req.body.city,
        state: req.body.state,
        postcode: req.body.postcode
        },
        { new: true}
    )

    if(!address)
    return res.status(400).send('the address cannot be created!')

    res.send(address);
})

router.delete('/:id', (req, res)=>{
    Address.findByIdAndRemove(req.params.id).then(address =>{
        if(address) {
            return res.status(200).json({success: true, message: 'the address is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "address not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;