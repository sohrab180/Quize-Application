const {Presentaion} = require('../models/presentation');
const express = require('express');
const router = express.Router();

router.get(`/`, async (req, res) =>{
    const presentationList = await Presentaion.find();

    if(!presentationList) {
        res.status(500).json({success: false})
    } 
   return res.status(200).send(presentationList);
})

router.get('/:id', async(req,res)=>{
    const presentation = await Presentaion.findById(req.params.id);

    if(!presentation) {
        res.status(500).json({message: 'The Presentaion with the given ID was not found.'})
    } 
     return res.status(200).send(presentation);
})



router.post('/', async (req,res)=>{
    let presentation = new Presentaion({
        titleSubjectpresented: req.body.titleSubjectpresented,
        subjectSeminar: req.body.subjectSeminar,
        organizingInstitutioName:req.body.organizingInstitutioName,
        durationFrom: req.body.durationFrom,
        durationTo: req.body.durationTo,
        whetherProceedingsPublished:req.body.whetherProceedingsPublished,
    })
    presentation = await presentation.save();

    if(!presentation)
    return res.status(400).send('the presentation cannot be created!')

    res.send(presentation);
});


router.put('/:id',async (req, res)=> {
    const presentation = await Presentaion.findByIdAndUpdate(
        req.params.id,
        {
        titleSubjectpresented: req.body.titleSubjectpresented,
        subjectSeminar: req.body.subjectSeminar,
        organizingInstitutioName:req.body.organizingInstitutioName,
        durationFrom: req.body.durationFrom,
        durationTo: req.body.durationTo,
        whetherProceedingsPublished:req.body.whetherProceedingsPublished,
        },
        { new: true}
    )

    if(!presentation)
    return res.status(400).send('the presentation cannot be created!')

    res.send(presentation);
})

router.delete('/:id', (req, res)=>{
    Presentaion.findByIdAndRemove(req.params.id).then(presentation =>{
        if(presentation) {
            return res.status(200).json({success: true, message: 'the presentation is deleted!'})
        } else {
            return res.status(404).json({success: false , message: "presentation not found!"})
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) 
    })
})

module.exports =router;