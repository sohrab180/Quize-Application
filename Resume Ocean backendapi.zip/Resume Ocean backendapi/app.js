const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const morgan = require('morgan');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv/config');
const authJwt = require('./helpers/jwt');
const errorHandler = require('./helpers/error-handler');
const jsonParser = bodyParser.json();



app.use(cors());
app.options('*', cors())

//middleware
app.use(bodyParser.json());
app.use(morgan('tiny'));
app.use(authJwt());
app.use(errorHandler);

//Routes
const categoriesRoutes = require('./routes/categories');
const productsRoutes = require('./routes/products');
const usersRoutes = require('./routes/users');
const ordersRoutes = require('./routes/orders');
const profilesRoutes = require('./routes/profiles');
const journalsRoutes = require('./routes/journals');
const conferencesRoutes = require('./routes/conferences');
const bookChaptersRoutes = require('./routes/bookChapters');
const booksRoutes = require('./routes/books');
const educationRoutes = require('./routes/educationQuals');
const personalRoutes = require('./routes/personalinfoms');
const addressRoutes = require('./routes/adresess');
const coCurricullar1Routes = require('./routes/co-curricullars1');
const coCurricullar2Routes = require('./routes/co-curricullars2');
const coCurricullar3Routes = require('./routes/co-curricullars3');
const patentRoutes = require('./routes/patents');
const miscellenousRoutes = require('./routes/miscellenous');
const rguidenceRoutes = require('./routes/research_guidences');
const rprojectRoutes = require('./routes/research_projects');
const presentationtRoutes = require('./routes/presentions');
const lectureRoutes = require('./routes/lectures');
const employmentRoutes = require('./routes/employments');
const profilePicRoutes = require('./routes/profilePics');
const digitalresumesRoutes = require('./routes/digitalResume');

const api = process.env.API_URL;

app.use(`${api}/categories`, categoriesRoutes);
app.use(`${api}/products`, productsRoutes);
app.use(`${api}/users`, usersRoutes);
app.use(`${api}/orders`, ordersRoutes);
app.use(`${api}/profiles`, profilesRoutes);
app.use(`${api}/journals`, journalsRoutes);
app.use(`${api}/conferences`, conferencesRoutes);
app.use(`${api}/bookChapters`, bookChaptersRoutes);
app.use(`${api}/books`, booksRoutes);
app.use(`${api}/education`, educationRoutes);
app.use(`${api}/personal`, personalRoutes);
app.use(`${api}/address`, addressRoutes);
app.use(`${api}/coCurricullar1`, coCurricullar1Routes);
app.use(`${api}/coCurricullar2`, coCurricullar2Routes);
app.use(`${api}/coCurricullar3`, coCurricullar3Routes);
app.use(`${api}/patent`, patentRoutes);
app.use(`${api}/miscellenous`, miscellenousRoutes);
app.use(`${api}/rguidence`, rguidenceRoutes);
app.use(`${api}/rproject`, rprojectRoutes);
app.use(`${api}/presentation`, presentationtRoutes);
app.use(`${api}/lectures`, lectureRoutes);
app.use(`${api}/employments`, employmentRoutes);
app.use(`${api}/profilePic`, profilePicRoutes);
app.use(`${api}/digitalResume`, digitalresumesRoutes);

//Database
mongoose.connect(process.env.CONNECTION_STRING, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    dbName: 'resumeOcean'
})
.then(()=>{
    console.log('Database Connection is ready...')
})
.catch((err)=> {
    console.log(err);
})

//Server
app.listen(8080, ()=>{

    console.log('server is running http://localhost:8080');
})